﻿using System;
using NServiceBus;
using Microsoft.WindowsAzure;

class Program
{

    static void Main()
    {
        BusConfiguration busConfiguration = new BusConfiguration();
        busConfiguration.EndpointName("Samples.Azure.ServiceBus.Endpoint2");
        busConfiguration.UseSerialization<JsonSerializer>();
        busConfiguration.EnableInstallers();
        busConfiguration.UsePersistence<InMemoryPersistence>();
        busConfiguration.ScaleOut().UseSingleBrokerQueue();
        //busConfiguration.UseTransport<AzureServiceBusTransport>()
            //.ConnectionString(Environment.GetEnvironmentVariable("SamplesAzureServiceBusConnection"));
        busConfiguration.UseTransport<AzureServiceBusTransport>()
            .ConnectionString("Endpoint=sb://sudhtest.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=roVv8fAHX5IB0Wn9THy34pfPlx5L39cR6SFyd/nnGvo=");
        //busConfiguration.UsePersistence<InMemoryPersistence>();
        //busConfiguration.UseTransport<AzureServiceBusTransport>()
        // .ConnectionString(CloudConfigurationManager.GetSetting("Microsoft.ServiceBus.ConnectionString"));
        using (IBus bus = Bus.Create(busConfiguration).Start())
        {
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}