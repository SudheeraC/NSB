﻿using System;
using NServiceBus;
using System.Reflection;
using Microsoft.WindowsAzure;

class Program
{

    static void Main()
    {
        #region config

        BusConfiguration busConfiguration = new BusConfiguration();
        busConfiguration.AssembliesToScan(Assembly.GetExecutingAssembly());
        busConfiguration.EndpointName("Samples.Azure.ServiceBus.Endpoint1");
        busConfiguration.UsePersistence<InMemoryPersistence>();
        busConfiguration.ScaleOut().UseSingleBrokerQueue();
        //busConfiguration.UseTransport<AzureServiceBusTransport>()
        //    .ConnectionString(Environment.GetEnvironmentVariable("SamplesAzureServiceBusConnection"));

        busConfiguration.UseTransport<AzureServiceBusTransport>()
                   .ConnectionString("Endpoint=sb://sudhtest.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=roVv8fAHX5IB0Wn9THy34pfPlx5L39cR6SFyd/nnGvo=");
       
        #endregion

        busConfiguration.UsePersistence<InMemoryPersistence>();
        busConfiguration.UseSerialization<JsonSerializer>();
        busConfiguration.EnableInstallers();

        using (IBus bus = Bus.Create(busConfiguration).Start())
        {
            Console.WriteLine("Press 'enter' to send a message");
            Console.WriteLine("Press any other key to exit");

            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey();
                Console.WriteLine();

                if (key.Key != ConsoleKey.Enter)
                {
                    return;
                }

                Guid orderId = Guid.NewGuid();
                Message1 message = new Message1
                {
                    Property = "Hello from Endpoint1"
                };
                bus.Send("Samples.Azure.ServiceBus.Endpoint2", message);
                Console.WriteLine("Message1 sent");
            }
        }
    }
}